<?xml version="1.0" standalone="no"?>
<!DOCTYPE vlcd PUBLIC "-//W3C//DTD VLCD 1.0//EN" "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/vlcd10.dtd">
<vlcd width="320" height="480">
<desc>Vlcd picture</desc>
</vlcd>
